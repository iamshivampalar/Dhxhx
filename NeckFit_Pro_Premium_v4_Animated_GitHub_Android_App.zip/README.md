# NeckFit Pro Premium v4 Animated

A premium offline Android posture exercise app with Indian theme UI, workout timer, progress badges, reminders, Hindi/English mode, dark mode, and animated exercise illustrations.

## New in v4

- GIF-style animated exercise illustrations in the app
- Actual GIF files included in `app/src/main/assets/gifs/`
- PNG frame animations included in `app/src/main/res/drawable/`
- Each exercise now shows step-by-step movement visuals
- GitHub Actions APK build workflow included

## Exercises Included

- Chin Tuck
- Shoulder Blade Squeeze
- Neck Side Stretch
- Neck Flexion Stretch
- Wall Posture Hold
- Chest Opener Stretch
- Phone Posture Practice

## Where images/animations are stored

GIF files:

```text
app/src/main/assets/gifs/
```

Drawable animation files used inside the app:

```text
app/src/main/res/drawable/anim_chin_tuck.xml
app/src/main/res/drawable/anim_shoulder_squeeze.xml
app/src/main/res/drawable/anim_side_stretch.xml
app/src/main/res/drawable/anim_flexion.xml
app/src/main/res/drawable/anim_wall_hold.xml
app/src/main/res/drawable/anim_chest_opener.xml
app/src/main/res/drawable/anim_phone_posture.xml
```

PNG frames:

```text
app/src/main/res/drawable/*_frame1.png
app/src/main/res/drawable/*_frame2.png
app/src/main/res/drawable/*_frame3.png
```

## GitHub build

1. Upload all project files to the root of your GitHub repo.
2. Open GitHub → Actions.
3. Run **Build NeckFit Pro APK**.
4. Download APK from workflow artifacts.

## Safety note

This app is for posture and fitness guidance only. It does not increase actual bone length. Stop if pain, dizziness, numbness, or tingling happens.
